export const USER_SIGN_UP = 'USER_SIGN_UP';
export const USER_SIGN_OUT = 'USER_SIGN_OUT';
export const SET_CURRENT_USER = 'SET_CURRENT_USER';
